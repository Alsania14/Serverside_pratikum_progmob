<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailEvent extends Model
{
    protected $table = 'detail_events';
}
