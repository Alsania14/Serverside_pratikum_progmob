<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

use App\Event;

class EventController extends Controller
{
    public function read(){
        $events = Event::all();
        
        foreach ($events as $event => $value) {
            $events[$event]->image = $events[$event]->EventFirstImage();
        }
        
        return response()->json($events);
    }

    public function create(Request $request){
        $validator = Validator::make($request->all(),[
            "user_id" => "required|numeric",
            "event_name" => "required|max:100",
            "description" => "required|max:200",
            "tanggal_mulai" => "required|date|before_or_equal:".$request->tanggal_selesai,
            "tanggal_selesai" => "required|date|after_or_equal:".$request->tanggal_mulai,
            "status" => Rule::in(["open","close","ongoing","done"])
        ]);

        if($validator->fails()){
            return response()->json(['status' => 403]);
        }
            $event = new Event;
            $event->user_id = $request->user_id;
            $event->nama = $request->event_name;
            $event->deskripsi = $request->description;
            $event->tanggal_mulai = $request->tanggal_mulai;
            $event->tanggal_selesai = $request->tanggal_selesai;
            $event->status = $request->status;
            $event->save();

            return response()->json(['status' => 200,"event_id" => $event->id]);
    }
    
    public function update(Request $request){
        $validator = Validator::make($request->all(),[
            "user_id" => "required|numeric",
            "event_name" => "required|max:100",
            "description" => "required|max:200",
            "tanggal_mulai" => "required|date|before_or_equal:".$request->tanggal_selesai,
            "tanggal_selesai" => "required|date|after_or_equal:".$request->tanggal_mulai,
            "status" => Rule::in(["open","close","ongoing","done"]),
            "event_id" => "required|numeric"
        ]);

        if($validator->fails()){
            return response()->json(['status' => 403]);
        }

            $event = Event::find($request->event_id);
            
    }

    public function delete(Request $request){
      $event = Event::find($request->id);
      $event->delete();

      return response()->json(['status' => 200]);
    }
}
