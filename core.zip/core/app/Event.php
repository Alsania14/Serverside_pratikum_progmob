<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    public function EventFirstImage(){
        return $this->hasMany('App\Event_image','event_id')->first()['image_name'];
    }
}
